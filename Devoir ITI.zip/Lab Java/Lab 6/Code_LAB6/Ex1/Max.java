public class Max { 
  public static <T extends Comparable<T>> T maxi(T[] tab) { 
    if (tab == null || tab.length == 0) {
        return null;
    }
    
    T maxElement = tab[0];
    for (int i = 1; i < tab.length; i++) {
        if (tab[i].compareTo(maxElement) > 0) {
            maxElement = tab[i];
        }
    }
    return maxElement;
  }
}


