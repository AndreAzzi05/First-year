import javax.smartcardio.Card;

public class Set {

    private static final String str = System.getProperty( "line.separator" );
        
    // Instance variable
    private Cashier[] set;

    // Constructor
    public Set( int nbr ) {
        //VOTRE CODE VIENT ICI
        if(nbr<1){
            throw new IllegalArgumentException();
        }


        set=new Cashier[nbr];
        for (int i=0;i<nbr;i++){
            set[i]=new Cashier();

        }
    }

    // Instance methods
    public void add (Client client) {
         //VOTRE CODE VIENT ICI
         int minIndex=0;
         int minLength=set[0].getQueueSize();
         for (int i=1;i<set.length;i++){
            int length=set[i].getQueueSize();
            if (length<minLength){
                minLength=length;
                minIndex=i;
            }
         }

         //Ajoutons le clions a la file la plus courte

         set[minIndex].add(client);
   }

    public void servedClients( int currentTime ) {
         //VOTRE CODE VIENT ICI
         for (Cashier cashier:set){
            cashier.servedClients(currentTime);
         }   
         }

    public String toString() {
        //VOTRE CODE VIENT ICI
        StringBuilder sb=new StringBuilder();
        for (int i=0;i<set.length;i++){
            sb.append("Line").append(i).append(":").append(str).append(set[i].toString()).append(str);

        }
        return sb.toString();
    }
}
