class Test1 {

    public static void main( String[] args ) {

    ListNode node = new ListNode();
    if ( node.size() != 0 )
     System.out.println( "List not empty " );

    System.out.println( "tested!" );
    }
}
