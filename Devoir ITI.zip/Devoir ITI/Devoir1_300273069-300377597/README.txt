Nom étudiant 1 : André Azzi

Nom étudiant 2 : Avery Ng

Numero d'étudiant 1: 300273069

Numero d'étudiant 2 : 300377597

Code du cours : ITI1521