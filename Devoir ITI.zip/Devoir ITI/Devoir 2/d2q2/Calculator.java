/**********************Q2-Devoir2 ITI1521*********/
class Calculator {
private double first, second; // two calculator operands
private String oP;  

Calculator() {};

void operation(String str) {
first = second; // keep first operand
second = 0; // initialize and get ready for second operand
oP = str;
}

void add() { 
  operation("+"); }
void subtract() { 
  operation("-");
}
void multiply() {
operation("*"); 
}
void divide() { 
operation("/"); 
}
void factorial() { 
first = display(); 
if (first < 0 || first != (int) first) {
System.out.println("input invalide pour factoriel");
return;
}

int fact = 1;
for (int i = 1; i <= first; i++) {
fact *= i;  
}

second = fact;
} 
void pow() { 
operation("POW");
} 
void rootSquare() { 
first = display();
if (first < 0) {
  System.out.println("Input invalide pour root! ");
  return;
}

second = Math.sqrt(first);
} 
void nepLog() { 
first = display();
if (first <= 0) {
  System.out.println("Input invalide pour logarithm naturel");
  return;
}

second = Math.log(first);
} 


void compute() 
if (oP.equals("+"))
second = first + second;
else if (oP.equals("-"))
second = first - second;
else if (oP.equals("*"))
second = first * second;
else if (oP.equals("/")) {
  if (second ==0) {
  System.out.println("Peut pas diviser par zero");
  return;
  }
second = first / second;
} else if{ (oP.equals("POW"))
second = Math.pow(first, second);}
else if{
 (oP.equals("="))
return;}


void set(double d){
  second=d;
}
void clear() {
first = 0;
second = 0;
oP = "";
}

double display() {
return second;
}
}






