import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class GUI extends JFrame implements ActionListener
    Calculator cal;
    JTextField input;

GUI(Calculator p) {
    cal = p;

setTitle("Calculator");
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
JPanel topPanel = new JPanel();
input = new JTextField(25);
topPanel.add(input);
add(topPanel, BorderLayout.NORTH);

JPanel buttonPanel = new JPanel();
buttonPanel.setLayout(new GridLayout(4, 4));

String[] buttonLabels ={"7", "8", "9", "/",
                        "4", "5", "6", "*",
                        "1", "2", "3", "-",
                        "0", "C", "=", "+"};
for (String label : buttonLabels) {
    JButton button = new JButton(label);
    button.addActionListener(this);
    buttonPanel.add(button);
}

    add(buttonPanel, BorderLayout.CENTER);

    pack();
    setLocationRelativeTo(null); // Center the window
    }

public void actionPerformed(ActionEvent e) 
        String str = e.getActionCommand();
// 
if (str.matches("[0-9]") || str.equals(".")) {
input.setText(input.getText() + str); 
} else 
// 
switch (str) {
case "C":
input.setText(""); 
cal.clear();
break;
case "=":
cal.Set(Double.parseDouble(input.getText())); 
cal.compute(); 
input.setText(String.valueOf(cal.display())); 
break;
case "+":
cal.Set(Double.parseDouble(input.getText()));
cal.add(); 
input.setText(""); // 
break;
case "-":
cal.Set(Double.parseDouble(input.getText())); // 
cal.subtract(); // 
input.setText(""); // 
break;
case "*":
cal.Set(Double.parseDouble(input.getText())); // 
cal.multiply(); // 
input.setText(""); //
break;
case "/":
cal.Set(Double.parseDouble(input.getText())); // 
cal.divide(); //
input.setText(""); // 
break;
case "POW":
cal.Set(Double.parseDouble(input.getText())); // 
cal.pow(); // 
input.setText(""); // 
break;
case "sqrt":
cal.Set(Double.parseDouble(input.getText())); // 
cal.rootSquare(); //
input.setText(""); // 
break;
case "log":
cal.Set(Double.parseDouble(input.getText())); // 
cal.nepLog(); // 
input.setText(""); // 
break;
default:
break;

public static void main(String arg[]) {
    GUI gui = new GUI(new Calculator());
    gui.setVisible(true);
    }
}

