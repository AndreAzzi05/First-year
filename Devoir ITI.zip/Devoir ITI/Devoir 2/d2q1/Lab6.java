public class Lab6 {

}
