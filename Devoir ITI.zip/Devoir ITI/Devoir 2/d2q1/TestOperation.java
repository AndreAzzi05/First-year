/**********************Q1-Devoir2 ITI1521....*/
/**
 * TestOperation
 */
public class TestOperation {
    
    private static Operation[] questions=new Operation[10] ;  // questions pour le test

    private static int[] reponses = new int[10];   // r�ponses de l'utilisateur aux questions
    private static void createTest (){
        for (int i=0;i<10;i++){
            questions[i]=new Operation();
        }
    }
    private static void creezTest() {
        questions = new Operation[10];//Question pour le test
        for (int i = 0; i < 10; i++){
            questions[i] = new Operation();
        }
        //VOTRE CODE ICI
    }//end of creezTest()
    private static void effectuezTest() {
        reponses = new int[10];//reponse de l'utilisateur
        int compteur = 0;

        for (int i = 0; i < 10; i++) {
            Operation Questionpresente = questions[i];
            int utilisateur;

            if (Questionpresente.getRand() == 0) {
                System.out.print("Question " + (i + 1) + ": " + Questionpresente.getQuestion0() + " ");
                utilisateur = ReadInt.getInt("[?]");
                if (utilisateur == Questionpresente.getAddition()) {
                    compteur++;
                } else {
                    System.out.println("INCORRECTE. La reponse est " + Questionpresente.getAddition());
                    
                    if (utilisateur == Questionpresente.getProduct()){
                        compteur++;
                    }
                    
                    else{
                        System.out.println("Ma");
                    }
                        
                    }
                }
                    else{
                        System.out.print("Question " + (i + 1) + ": " + Questionpresente.getQuestion1()+ " ");
                        utilisateur = ReadInt.getInt("[?]");
                        if (utilisateur == Questionpresente.getProduct()){
                            compteur++;
                        } else {
                            System.out.println("INCORECTE. La reponse est" + Questionpresente.getProduct());
                            
                        }
                    }

                    reponses[i] = utilisateur;
                }

                System.out.println("\nTu as " + compteur + " bonne reponse.");
                double score = (double) compteur / 10 * 100;
                System.out.println("Ton score est" + score + "%.");

            }
    
   
    /*
     * Programme principal main
     */ 
    public static void main(String[] args) {
        System.out.println();
        System.out.println("SVP r�pondre aux 10 questions d'operations arithmetiques suivantes :");
        System.out.println();
        creezTest();
        effectuezTest();
   }//end of main()
    

} // end class OperationTest 
