
public class TestMax { 
  
  public static void main (String args[]) { 
    Integer [] tab = {20, 7, 1, 0, 10, 7, 4, 91 } ;
    System.out.println( "Valeur maximale de tab est : " + Max.maxi (tab) ) ;
  }

}

