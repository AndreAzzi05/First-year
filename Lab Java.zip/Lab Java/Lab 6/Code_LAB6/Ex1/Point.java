class Point implements Comparable<Point> { 
  private int x, y ;
  
  Point (int x, int y){ 
      this.x = x ;
      this.y = y ;
  }

  public void display() { 
      System.out.println ( x + " " + y ) ;
  }

//VOTRE CODE
  public int compareTo(Point p) { 
      int thisDistanceSquared = this.x * this.x + this.y * this.y;
      int pDistanceSquared = p.x * p.x + p.y * p.y;
      
      if (thisDistanceSquared == pDistanceSquared) {
          return 0;
      } else if (thisDistanceSquared < pDistanceSquared) {
          return -1;
      } else {
          return 1;
      }
  }
}
