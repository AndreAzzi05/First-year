public class Max  {
    public static <T extends Comparable<T> > T max1 (T[] tab) {
        if (tab == null || tab.length == 0) {
            System.out.println("Le tableau est vide ou null");
        }

        T Grand_element = tab[0];

        for (int i = 1; i < tab.length; i++) {
            if (tab[i].compareTo(Grand_element)>0){
                Grand_elemenet = tab[i];
            }
        }

    return Grand_element;
    }

}
